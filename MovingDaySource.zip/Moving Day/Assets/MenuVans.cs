﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuVans : MonoBehaviour
{

    public GameObject van;

	// Use this for initialization
	void Start ()
	{
	}
}
