# MovingDay
Arthur is a stinky willy idiot bitch
